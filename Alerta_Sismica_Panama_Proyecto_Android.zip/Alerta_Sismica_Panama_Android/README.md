# Alerta Sísmica Panamá — proyecto Android

Este proyecto integra la última versión de la página en una app Android mediante WebView.

## Importante
Este ZIP contiene el código fuente y la automatización para compilar el APK; **no contiene un APK ya compilado**. En este entorno no están instalados Android SDK/Gradle y no hay conexión de red para descargar las herramientas necesarias, por lo que no puedo compilar ni probar un APK aquí.

## Cómo obtener el APK sin pagar Replit
1. Crea un repositorio en GitHub e inicia sesión.
2. Sube el contenido de esta carpeta al repositorio (no la carpeta contenedora completa dentro de otra carpeta).
3. Abre la pestaña **Actions** y ejecuta **Compilar APK Android** con **Run workflow**. También se ejecuta al subir código a `main` o `master`.
4. Cuando termine correctamente, abre la ejecución y descarga el artefacto **Alerta-Sismica-Panama-APK**. Dentro estará `app-debug.apk`.
5. Descarga el APK en tu Android y ábrelo para instalarlo. Es posible que Android te pida autorizar instalaciones desde esa fuente.

## Requisitos y límites
- La app necesita Internet para cargar el mapa y consultar las fuentes web.
- Ubicación y notificaciones requieren permisos del sistema.
- Esta base aún no implementa un servicio nativo persistente de alertas en segundo plano; las notificaciones de la página no equivalen a una alerta garantizada cuando la app está cerrada.
- No es un sistema certificado ni puede garantizar avisos antes de que empiece un temblor.
